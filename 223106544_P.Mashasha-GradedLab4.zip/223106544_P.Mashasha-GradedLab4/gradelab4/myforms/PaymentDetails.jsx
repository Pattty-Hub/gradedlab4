import React, { useState, useContext } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { FormContext } from '../context/FormContext';
import { useNavigation } from '@react-navigation/native';

const Form3Screen = () => {
  const { formData, setFormData } = useContext(FormContext);
  const navigation = useNavigation();

  const [cardNumber, setCardNumber] = useState(formData.cardNumber || '');
  const [expiryMonth, setExpiryMonth] = useState(formData.expiryMonth || '');
  const [expiryYear, setExpiryYear] = useState(formData.expiryYear || '');
  const [cvv, setCvv] = useState(formData.cvv || '');

  // Basic Validation
  const validateFields = () => {
    if (
      cardNumber.trim() === '' ||
      expiryMonth.trim() === '' ||
      expiryYear.trim() === '' ||
      cvv.trim() === ''
    ) {
      Alert.alert('Error', 'All fields are required.');
      return false;
    }

    // Validate card number (16 digits)
    const cardNumberRegex = /^\d{16}$/;
    if (!cardNumberRegex.test(cardNumber)) {
      Alert.alert('Error', 'Please enter a valid 16-digit credit card number.');
      return false;
    }

    // Validate expiration month (01-12)
    const monthRegex = /^(0[1-9]|1[0-2])$/;
    if (!monthRegex.test(expiryMonth)) {
      Alert.alert('Error', 'Please enter a valid expiration month (01-12).');
      return false;
    }

    // Validate expiration year (assume current year + 10 years)
    const currentYear = new Date().getFullYear();
    const yearRegex = new RegExp(`^(${currentYear}|${currentYear + 1}|${currentYear + 2}|${currentYear + 3}|${currentYear + 4}|${currentYear + 5}|${currentYear + 6}|${currentYear + 7}|${currentYear + 8}|${currentYear + 9}|${currentYear + 10})$`);
    if (!yearRegex.test(expiryYear)) {
      Alert.alert('Error', 'Please enter a valid expiration year.');
      return false;
    }

    // Validate CVV (3 digits)
    const cvvRegex = /^\d{3}$/;
    if (!cvvRegex.test(cvv)) {
      Alert.alert('Error', 'Please enter a valid 3-digit CVV.');
      return false;
    }

    return true;
  };

  const handleSubmit = () => {
    if (validateFields()) {
      setFormData({ ...formData, cardNumber, expiryMonth, expiryYear, cvv });
      // Final submission logic here
      Alert.alert('Success', 'Payment details submitted successfully!');
      // Optionally, navigate to a summary or home screen
      navigation.navigate('HomeScreen'); // Replace 'HomeScreen' with your target screen
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Credit Card Number</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your 16-digit card number"
        value={cardNumber}
        onChangeText={setCardNumber}
        keyboardType="numeric"
        maxLength={16}
      />

      <Text style={styles.label}>Expiration Month (MM)</Text>
      <TextInput
        style={styles.input}
        placeholder="MM"
        value={expiryMonth}
        onChangeText={setExpiryMonth}
        keyboardType="numeric"
        maxLength={2}
      />

      <Text style={styles.label}>Expiration Year (YYYY)</Text>
      <TextInput
        style={styles.input}
        placeholder="YYYY"
        value={expiryYear}
        onChangeText={setExpiryYear}
        keyboardType="numeric"
        maxLength={4}
      />

      <Text style={styles.label}>CVV</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your 3-digit CVV"
        value={cvv}
        onChangeText={setCvv}
        keyboardType="numeric"
        maxLength={3}
      />

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    fontSize: 16,
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Form3Screen;
