import React, { useState, useContext } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { FormContext } from '../context/FormContext';
import { useNavigation } from '@react-navigation/native';

const Form2Screen = () => {
  const { formData, setFormData } = useContext(FormContext);
  const navigation = useNavigation();

  const [address, setAddress] = useState(formData.address || '');
  const [city, setCity] = useState(formData.city || '');
  const [state, setState] = useState(formData.state || '');
  const [zip, setZip] = useState(formData.zip || '');

 
  const validateFields = () => {
    if (address.trim() === '' || city.trim() === '' || state.trim() === '' || zip.trim() === '') {
      Alert.alert('Error', 'All fields are required.');
      return false;
    }

    const zipRegex = /^\d{3}$/;
    if (!zipRegex.test(zip)) {
      Alert.alert('Error', 'Please enter a valid 3-digit zip code.');
      return false;
    }
    return true;
  };

  const handleNext = () => {
    if (validateFields()) {
      setFormData({ ...formData, address, city, state, zip });
      navigation.navigate('Form3Screen'); 
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Address</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your address"
        value={address}
        onChangeText={setAddress}
      />

      <Text style={styles.label}>City</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your city"
        value={city}
        onChangeText={setCity}
      />

      <Text style={styles.label}>State</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your state"
        value={state}
        onChangeText={setState}
      />

      <Text style={styles.label}>Zip Code</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your zip code"
        value={zip}
        onChangeText={setZip}
        keyboardType="numeric"
      />

      <TouchableOpacity style={styles.button} onPress={handleNext}>
        <Text style={styles.buttonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    fontSize: 16,
    marginBottom: 20,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Form2Screen;

  
