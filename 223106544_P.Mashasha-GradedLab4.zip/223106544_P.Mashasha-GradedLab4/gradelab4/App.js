import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import MenuScreen from './components/MenuScreen';
import CartScreen from './components/CartScreen';
import ProfileScreen from './components/ProfileScreen';
import AddressDetails from './myforms/AddressDetails';
import PaymentDetails from './myforms/PaymentDetails';
import UserDetails from './myforms/UserDetails';

import { FormProvider } from './context/FormContext';
import { ThemeProvider } from './context/ThemeContext';
import { CartProvider } from './context/CartContext';

const Stack = createStackNavigator();

const App = () => {
  return (
    <FormProvider>
      <ThemeProvider>
        <CartProvider>
          <NavigationContainer>
            <Stack.Navigator initialRouteName="Menu">
              <Stack.Screen name="Menu" component={MenuScreen} />
              <Stack.Screen name="Cart" component={CartScreen} />
              <Stack.Screen name="Profile" component={ProfileScreen} />
              <Stack.Screen name="Form1" component={UserDetails} />
              <Stack.Screen name="Form2" component={AddressDetails} />
              <Stack.Screen name="Form3" component={PaymentDetails} />
            </Stack.Navigator>
          </NavigationContainer>
        </CartProvider>
      </ThemeProvider>
    </FormProvider>
  );
};

export default App;


