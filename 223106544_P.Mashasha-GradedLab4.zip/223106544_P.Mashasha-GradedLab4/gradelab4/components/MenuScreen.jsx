import React, { useContext } from 'react';
import { View, Text, Button, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { CartContext } from '../context/CartContext';

const MenuScreen = () => {
  const { addItemToCart } = useContext(CartContext);

  // Sample food items
  const foodItems = [
    { id: 1, name: 'Burger', description: 'Delicious beef burger', price: 50, image: require('../assets/burger.jpeg') },
    { id: 2, name: 'Pizza', description: 'Cheesy pepperoni pizza', price: 80, image: require('../assets/pizza.jpeg') },
    { id: 3, name: 'Pasta', description: 'Creamy Alfredo pasta', price: 60, image: require('../assets/pasta.jpeg') },
    { id: 4, name: 'Salad', description: 'Healthy green salad', price: 40, image: require('../assets/salad.jpeg') },
    { id: 5, name: 'Fries', description: 'Crispy French fries', price: 30, image: require('../assets/fries.jpeg') },
    { id: 6, name: 'Ice Cream', description: 'Vanilla ice cream', price: 20, image: require('../assets/icecream.jpeg') },
  ];

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Image source={item.image} style={styles.image} />
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.description}>{item.description}</Text>
      <Text style={styles.price}>R{item.price}</Text>
      <TouchableOpacity style={styles.button} onPress={() => addItemToCart(item)}>
        <Text style={styles.buttonText}>Add to Cart</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <FlatList
      data={foodItems}
      keyExtractor={(item) => item.id.toString()}
      renderItem={renderItem}
      contentContainerStyle={styles.container}
      numColumns={2} 
    />
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 10,
  },
  itemContainer: {
    flex: 1,
    margin: 10,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  description: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
    textAlign: 'center',
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#28a745',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});

export default MenuScreen;
