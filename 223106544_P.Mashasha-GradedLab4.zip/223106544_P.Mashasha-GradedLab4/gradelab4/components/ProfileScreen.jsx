import React, { useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput } from 'react-native';
import { FormContext } from '../context/FormContext';
import { ThemeContext } from '../context/ThemeContext';

const ProfileScreen = () => {
  const { formData } = useContext(FormContext);
  const { theme, updateTheme } = useContext(ThemeContext);

  const [textColor, setTextColor] = React.useState(theme.textColor);
  const [backgroundColor, setBackgroundColor] = React.useState(theme.backgroundColor);

  const handleSaveTheme = () => {
    updateTheme(textColor, backgroundColor);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      
      <View style={[styles.card, { borderColor: theme.textColor }]}>
        <Text style={[styles.cardTitle, { color: theme.textColor }]}>Personal Information</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Name: {formData.name}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Email: {formData.email}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Phone: {formData.phone}</Text>
      </View>

      <View style={[styles.card, { borderColor: theme.textColor }]}>
        <Text style={[styles.cardTitle, { color: theme.textColor }]}>Address Information</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Address: {formData.address}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>City: {formData.city}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>State: {formData.state}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Zip: {formData.zip}</Text>
      </View>

      <View style={[styles.card, { borderColor: theme.textColor }]}>
        <Text style={[styles.cardTitle, { color: theme.textColor }]}>Payment Information</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Card Number: **** **** **** {formData.cardNumber.slice(-4)}</Text>
        <Text style={[styles.cardText, { color: theme.textColor }]}>Expiration Date: {formData.expirationDate}</Text>
      </View>

      
      <View style={[styles.customizationContainer, { borderColor: theme.textColor }]}>
        <Text style={[styles.customizationTitle, { color: theme.textColor }]}>Customize Theme</Text>
        <TextInput
          style={[styles.input, { borderColor: theme.textColor, color: theme.textColor }]}
          placeholder="Text Color (e.g., #000000)"
          placeholderTextColor={theme.textColor}
          value={textColor}
          onChangeText={setTextColor}
        />
        <TextInput
          style={[styles.input, { borderColor: theme.textColor, color: theme.textColor }]}
          placeholder="Background Color (e.g., #FFFFFF)"
          placeholderTextColor={theme.textColor}
          value={backgroundColor}
          onChangeText={setBackgroundColor}
        />
        <TouchableOpacity style={[styles.button, { backgroundColor: theme.textColor }]} onPress={handleSaveTheme}>
          <Text style={[styles.buttonText, { color: theme.backgroundColor }]}>Save Theme</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  card: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  cardText: {
    fontSize: 16,
    marginBottom: 5,
  },
  customizationContainer: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 15,
  },
  customizationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  button: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;
